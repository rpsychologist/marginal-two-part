get_power.plcp_hurdle <- function(object, df = "between", alpha = 0.05, progress = TRUE, R = 1L, cores = 1L, ...) {
    stop("Not supported, use ?simulate.plcp to calculate power for hurdle models.", call. = FALSE)
}
